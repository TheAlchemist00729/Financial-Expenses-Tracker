# Sprint 1 Backlog

| ID      | Requirement Description                                     | User Story ID | Priority | Effort (Fibonacci) |
|---------|-------------------------------------------------------------|---------------|----------|---------------------|
| RQT-01  | The system shall allow users to input their expenses.       | US-01         | High     | 2                   |
| RQT-02  | The system shall allow users to remove their expenses.      | US-02         | High     | 2                   |
| RQT-04  | The system shall allow users to track their expenses.       | US-04         | High     | 3                   |
| RQT-10  | The system shall allow users to set budgets.                | US-10         | Medium   | 5                   |
| RQT-13  | The system shall allow users to create a username/password. | US-13         | High     | 2                   |
